from setuptools import setup

setup(
    name='codicent-py',
    version='1.3.3',
    packages=['codicentpy'],
    install_requires=['requests'],
)
