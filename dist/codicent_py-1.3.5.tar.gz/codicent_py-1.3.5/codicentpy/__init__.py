from .core import Codicent
import requests
requests = requests